import { Link, Outlet, NavLink } from "react-router-dom";

export default function AdminLayout() {
  return (
    <div className="min-h-screen flex">
      {/* Sidebar */}
      <aside className="w-64 bg-slate-900 text-white shadow-lg">
        <div className="p-6 border-b border-slate-700">
          <h1 className="text-2xl font-bold">🛕 Temple Admin</h1>
        </div>

        <nav className="p-4 space-y-2">
          <Link
            to="/admin"
            className="block rounded-lg px-4 py-3 hover:bg-slate-800 transition"
          >
            📊 Dashboard
          </Link>

          <NavLink
            to="/admin/temples"
            className={({ isActive }) =>
              `block rounded-lg px-4 py-3 ${isActive ? "bg-slate-700" : "hover:bg-slate-800"
              }`
            }
          >
            🏛 Temple Management
          </NavLink>

          <Link
            to="/admin/darshan-types"
            className="block rounded-lg px-4 py-3 hover:bg-slate-800 transition"
          >
            🙏 Darshan Types
          </Link>

          <NavLink
            to="/admin/ticket-slots"
            className={({ isActive }) =>
              `block rounded-lg px-4 py-3 ${isActive ? "bg-slate-700" : "hover:bg-slate-800"
              }`
            }
          >
            🎫 Ticket Slots
          </NavLink>

          <Link
            to="/admin/bookings"
            className="block rounded-lg px-4 py-3 hover:bg-slate-800 transition"
          >
            📖 Bookings
          </Link>

          <Link
            to="/admin/payments"
            className="block rounded-lg px-4 py-3 hover:bg-slate-800 transition"
          >
            💳 Payments
          </Link>

          <Link
            to="/admin/reports"
            className="block rounded-lg px-4 py-3 hover:bg-slate-800 transition"
          >
            📈 Reports
          </Link>

          <Link
            to="/admin/users"
            className="block rounded-lg px-4 py-3 hover:bg-slate-800 transition"
          >
            👥 Users
          </Link>

          <hr className="border-slate-700 my-4" />

          <Link
            to="/"
            className="block rounded-lg px-4 py-3 hover:bg-red-600 transition"
          >
            🚪 Logout
          </Link>
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 bg-gray-100 p-8 overflow-auto">
        <Outlet />
      </main>
    </div>
  );
}