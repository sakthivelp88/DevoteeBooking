import { useEffect, useState } from "react";

export default function AdminBookings() {

  const [bookings, setBookings] =
    useState([]);

  useEffect(() => {

    fetch(
      "http://localhost:5000/api/admin/bookings",
      {
        credentials: "include",
      }
    )
      .then(res => res.json())
      .then(setBookings);

  }, []);

  return (
    <div>

      <h1 className="text-3xl font-bold mb-6">
        Bookings
      </h1>

      <table className="w-full bg-white shadow rounded">

        <thead>

          <tr className="bg-gray-200">

            <th className="p-3">
              Devotee
            </th>

            <th className="p-3">
              Amount
            </th>

            <th className="p-3">
              Payment
            </th>

          </tr>

        </thead>

        <tbody>

          {bookings.map(
            booking => (
              <tr
                key={booking._id}
                className="border-b text-center"
              >
                <td className="p-3">
                  {
                    booking.userId
                      ?.name
                  }
                </td>

                <td className="p-3">
                  ₹{booking.amount}
                </td>

                <td className="p-3">
                  {
                    booking.paymentStatus
                  }
                </td>
              </tr>
            )
          )}

        </tbody>

      </table>

    </div>
  );
}