import { useEffect, useState } from "react";

export default function AdminDashboard() {

  const [stats, setStats] =
    useState(null);

  useEffect(() => {
    loadAdminData();
  }, []);

  const loadAdminData = async () => {

    const res = await fetch(
      "http://localhost:5000/api/admin/dashboard",
      {
        credentials: "include",
      }
    );

    if (!res.ok) {
      const error = await res.json();
      alert(error.message);
      return;
    }

    const data = await res.json();

    setStats(data);
  };

  if (!stats)
    return <h2>Loading...</h2>;

  return (
  <div>

    <h1 className="text-4xl font-bold mb-8">
      Dashboard
    </h1>

    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">

      <div className="bg-white p-6 rounded-xl shadow">
        <p className="text-gray-500">
          Users
        </p>

        <h2 className="text-4xl font-bold text-blue-600">
          {stats.totalUsers}
        </h2>
      </div>

      <div className="bg-white p-6 rounded-xl shadow">
        <p className="text-gray-500">
          Tickets
        </p>

        <h2 className="text-4xl font-bold text-green-600">
          {stats.totalTickets}
        </h2>
      </div>

      <div className="bg-white p-6 rounded-xl shadow">
        <p className="text-gray-500">
          Bookings
        </p>

        <h2 className="text-4xl font-bold text-purple-600">
          {stats.totalBookings}
        </h2>
      </div>

      <div className="bg-white p-6 rounded-xl shadow">
        <p className="text-gray-500">
          Revenue
        </p>

        <h2 className="text-4xl font-bold text-red-600">
          ₹{stats.revenue}
        </h2>
      </div>

    </div>

  </div>
);
}