import axios from "axios";

const API = "http://localhost:5000/api";

export const bookTicket = async (
  ticketId,
  quantity
) => {
  const response = await axios.post(
    `${API}/bookings`,
    {
      ticketId,
      quantity,
    },
    {
      withCredentials: true,
    }
  );

  return response.data;
};