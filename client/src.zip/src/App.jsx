import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Toaster } from "react-hot-toast";

// Layouts
import AdminLayout from "./layouts/AdminLayout";

// Components
import Navbar from "./components/Navbar";
import ProtectedRoute from "./components/ProtectedRoute";
import AdminRoute from "./components/AdminRoute";

// User Pages
import Home from "./pages/user/Home";
import Login from "./pages/user/Login";
import Register from "./pages/user/Register";
import Dashboard from "./pages/user/Dashboard";
import TempleDetails from "./pages/user/TempleDetails";
import Tickets from "./pages/user/Tickets";
import MyBookings from "./pages/user/MyBookings";

// Admin Pages
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminTemples from "./pages/admin/AdminTemples";
import AdminDarshanTypes from "./pages/admin/AdminDarshanTypes";
import AdminTicketSlots from "./pages/admin/AdminTicketSlots";
import AdminBookings from "./pages/admin/AdminBookings";
import CreateTicket from "./pages/admin/AdminCreateTicket";
import AdminCreateTicket from "./pages/admin/AdminCreateTicket";

function App() {
  return (
    <BrowserRouter>
      <Toaster position="top-right" />
      <Navbar />

      <Routes>

        {/* ================= PUBLIC ROUTES ================= */}

        <Route path="/" element={<Home />} />

        <Route path="/login" element={<Login />} />

        <Route path="/register" element={<Register />} />

        {/* ================= USER ROUTES ================= */}

        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          }
        />

        <Route
          path="/temples/:id"
          element={
            <ProtectedRoute>
              <TempleDetails />
            </ProtectedRoute>
          }
        />

        <Route
          path="/tickets/:templeId/:darshanTypeId"
          element={
            <ProtectedRoute>
              <Tickets />
            </ProtectedRoute>
          }
        />

        <Route
          path="/my-bookings"
          element={
            <ProtectedRoute>
              <MyBookings />
            </ProtectedRoute>
          }
        />

        {/* ================= ADMIN ROUTES ================= */}

        <Route
          path="/admin"
          element={
            <AdminRoute>
              <AdminLayout />
            </AdminRoute>
          }
        >
          <Route index element={<AdminDashboard />} />

          <Route
            path="temples"
            element={<AdminTemples />}
          />

          <Route
            path="darshan-types"
            element={<AdminDarshanTypes />}
          />

          <Route
            path="ticket-slots"
            element={<AdminTicketSlots />}
          />

          <Route
            path="ticket-slots/create"
            element={<CreateTicket />}
          />

          <Route
            path="ticket-slots/edit/:id"
            element={<AdminCreateTicket />}
          />

          <Route
            path="bookings"
            element={<AdminBookings />}
          />
        </Route>

        {/* ================= 404 ================= */}

        <Route
          path="*"
          element={
            <div className="flex items-center justify-center h-screen">
              <h1 className="text-4xl font-bold text-red-600">
                404 - Page Not Found
              </h1>
            </div>
          }
        />

      </Routes>
    </BrowserRouter>
  );
}

export default App;