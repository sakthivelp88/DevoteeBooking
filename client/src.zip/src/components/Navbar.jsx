import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const Navbar = () => {
  const navigate = useNavigate();

  const { user, logout, isAdmin } = useAuth();

  const handleLogout = async () => {
    try {
      const success = await logout();

      if (success) {
        navigate("/login");
      }
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <nav className="bg-orange-600 text-white shadow">
      <div className="max-w-7xl mx-auto flex justify-between items-center px-6 py-4">
        <Link
          to="/"
          className="text-2xl font-bold"
        >
          Temple Booking
        </Link>

        <div className="flex items-center gap-6">
          <Link to="/temples">Temples</Link>

          {user && (
            <Link to="/my-bookings">
              My Bookings
            </Link>
          )}

          {isAdmin && (
            <Link to="/admin/dashboard">
              Admin
            </Link>
          )}

          {!user ? (
            <>
              <Link to="/login">Login</Link>

              <Link to="/register">
                Register
              </Link>
            </>
          ) : (
            <>
              <span className="font-medium">
                Welcome, {user.name}
              </span>

              <button
                onClick={handleLogout}
                className="bg-white text-orange-600 px-4 py-2 rounded hover:bg-gray-100"
              >
                Logout
              </button>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;