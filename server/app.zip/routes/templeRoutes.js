import express from "express";
import {
  getTemples,
  getTempleById,
  createTemple,
  updateTemple,
  deleteTemple,
} from "../controllers/templeController.js";

import { auth } from "../middleware/auth.js";
import { admin } from "../middleware/admin.js";

const router = express.Router();

router.get("/", getTemples);

router.get("/:id", getTempleById);

router.post("/", auth, admin, createTemple);

router.put("/:id", auth, admin, updateTemple);

router.delete("/:id", auth, admin, deleteTemple);

export default router;