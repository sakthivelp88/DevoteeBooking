import express from "express";

import { auth } from "../middleware/auth.js";

import { myBookings,} from "../controllers/bookingController.js";

const router = express.Router();

router.get("/my", auth, myBookings);

export default router;