import express from "express";

import { auth } from "../middleware/auth.js";
import { admin } from "../middleware/admin.js";
import { adminDashboard, getBookings} from "../controllers/adminController.js";


const router = express.Router();

router.get("/dashboard", auth, admin, adminDashboard);

router.get("/bookings", auth, admin, getBookings);

export default router;