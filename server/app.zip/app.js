import express from "express";
import cors from "cors";
import session from "express-session";
import MongoStore from "connect-mongo";

import authRoutes from "./routes/authRoutes.js";
import ticketRoutes from "./routes/ticketRoutes.js";
import bookingRoutes from "./routes/bookingRoutes.js";
import paymentRoutes from "./routes/paymentRoutes.js";
import dashboardRoutes from "./routes/dashboardRoutes.js";
import adminRoutes from "./routes/adminRoutes.js";
import templeRoutes from "./routes/templeRoutes.js";
import darshanTypeRoutes from "./routes/darshanTypeRoutes.js";

const app = express();

import path from "path";

app.use(express.json());

app.use(
  cors({
    origin: "http://localhost:5173",
    credentials: true
  })
);
app.use(
  session({
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: false,
      maxAge: 1000 * 60 * 60 * 24,
    },
  })
);

app.use("/api/admin", adminRoutes);

app.use("/api/auth", authRoutes);

app.use("/api/tickets", ticketRoutes);

app.use("/api/bookings", bookingRoutes);

app.use("/api/payment", paymentRoutes);

app.use("/api/dashboard", dashboardRoutes);

app.use("/api/temples", templeRoutes);

app.use("/api/darshan-types", darshanTypeRoutes);

app.use("/uploads", express.static("uploads"));

export default app;



