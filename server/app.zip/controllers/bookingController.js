import Booking from "../models/Booking.js";

// Logged-in user's bookings
export const myBookings = async (req, res) => {
  try {
    const bookings = await Booking.find({
      user: req.session.user.id,
    })
      .populate("temple", "name")
      .populate("darshanType", "name fee")
      .populate("ticket")
      .sort({ createdAt: -1 });

    return res.json({
      success: true,
      booking,
    });  
} catch (error) {
  res.status(500).json({
    success: false,
    message: error.message,
  });
}
};