import User from "../models/User.js";
import Ticket from "../models/Ticket.js";
import Booking from "../models/Booking.js";

export const adminDashboard =
  async (req, res) => {

  try {

    const totalUsers = await User.countDocuments();

    const totalTickets = await Ticket.countDocuments();

    const totalBookings = await Booking.countDocuments();

    const revenueData = await Booking.aggregate([
        {
          $match: {
            paymentStatus: "Paid",
          },
        },
        {
          $group: {
            _id: null,
            revenue: {
              $sum: "$amount",
            },
          },
        },
      ]);

    const revenue =
      revenueData[0]?.revenue || 0;

    res.json({
      totalUsers,
      totalTickets,
      totalBookings,
      revenue,
    });

  } catch (error) {

    res.status(500).json({
      message: error.message,
    });
  }
};

export const getBookings =
  async (req, res) => {
    try {

      const bookings =
        await Booking.find()
          .populate("userId")
          .populate("ticketId");

      res.json(bookings);

    } catch (error) {

      res.status(500).json({
        message: error.message,
      });

    }
  };