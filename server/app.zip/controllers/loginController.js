export const login = async (req, res) => {
  try {
    const { emailOrPhone, password } = req.body;    

    const user = await User.findOne({
      $or: [
        { email: emailOrPhone },
        { phone: emailOrPhone }
      ]
    });   

    // if (user) {
    //   console.log("DB PASSWORD:", user.password);
    //   console.log("INPUT PASSWORD:", password);
    // }

    if (!user) {
      return res.status(400).json({
        message: "Invalid credentials",
      });
    }

    const isMatch = await bcrypt.compare(
      password,
      user.password
    );    

    if (!isMatch) {
      return res.status(400).json({
        message: "Invalid credentials",
      });
    }

    req.session.user = {
      id: user._id,
      role: user.role,
      name: user.name,
    };   

      res.json({
        success: true,
        user: req.session.user,
      });
    
    res.json({
      success: true,
      user: req.session.user,
    });
  } catch (error) {
    console.error("Login Error:", error);

    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};