import Ticket from "../models/Ticket.js";

export const createTicket = async (req, res) => {
  try {
    console.log(req.body);

    const ticket = await Ticket.create(req.body);

    res.status(201).json({
      success: true,
      message: "Ticket created successfully.",
      ticket,
    });
  } catch (error) {
    console.error(error);

    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const updateTicket = async (req, res) => {
  try {
    const ticket = await Ticket.findById(req.params.id);

    if (!ticket) {
      return res.status(404).json({
        success: false,
        message: "Ticket not found.",
      });
    }

    const bookedSeats = ticket.totalSeats - ticket.availableSeats;

    if (
      req.body.totalSeats &&
      req.body.totalSeats < bookedSeats
    ) {
      return res.status(400).json({
        success: false,
        message: "Total seats cannot be less than booked seats.",
      });
    }

    Object.assign(ticket, req.body);

    if (req.body.totalSeats) {
      ticket.availableSeats =
        req.body.totalSeats - bookedSeats;
    }

    await ticket.save();

    res.json({
      success: true,
      message: "Ticket updated successfully.",
      ticket,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const updateTicketStatus = async (req, res) => {
  try {
    const { status } = req.body;

    const ticket = await Ticket.findById(req.params.id);

    if (!ticket) {
      return res.status(404).json({
        success: false,
        message: "Ticket not found.",
      });
    }

    ticket.status = status;

    await ticket.save();

    res.json({
      success: true,
      message: `Ticket ${status.toLowerCase()} successfully.`,
      ticket,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const deleteTicket = async (req, res) => {
  try {
    const ticket = await Ticket.findById(req.params.id);

    if (!ticket) {
      return res.status(404).json({
        success: false,
        message: "Ticket not found.",
      });
    }

    ticket.status = "Closed";

    await ticket.save();

    res.json({
      success: true,
      message: "Ticket closed successfully.",
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const getTickets = async (req, res) => {
  try {
    // ===============================
    // Query Parameters
    // ===============================
    const {
      search = "",
      sortBy = "date",
      sortOrder = "asc",
    } = req.query;

    // ===============================
    // Allowed Sort Fields
    // ===============================
    const allowedSortFields = [
      "date",
      "price",
      "availableSeats",
      "totalSeats",
      "status",
    ];

    const sortField = allowedSortFields.includes(sortBy)
      ? sortBy
      : "date";

    // ===============================
    // Aggregation Pipeline
    // ===============================
    const pipeline = [
      // Temple Lookup
      {
        $lookup: {
          from: "temples",
          localField: "temple",
          foreignField: "_id",
          as: "temple",
        },
      },
      {
        $unwind: "$temple",
      },

      // Darshan Type Lookup
      {
        $lookup: {
          from: "darshantypes",
          localField: "darshanType",
          foreignField: "_id",
          as: "darshanType",
        },
      },
      {
        $unwind: "$darshanType",
      },
    ];

    // ===============================
    // Global Search
    // ===============================
    if (search?.trim()) {
      pipeline.push({
        $match: {
          $or: [
            {
              "temple.name": {
                $regex: search,
                $options: "i",
              },
            },
            {
              "darshanType.name": {
                $regex: search,
                $options: "i",
              },
            },
            {
              status: {
                $regex: search,
                $options: "i",
              },
            },
            {
              slotStart: {
                $regex: search,
                $options: "i",
              },
            },
            {
              slotEnd: {
                $regex: search,
                $options: "i",
              },
            },
            {
              $expr: {
                $regexMatch: {
                  input: { $toString: "$price" },
                  regex: search,
                  options: "i",
                },
              },
            },
            {
              $expr: {
                $regexMatch: {
                  input: { $toString: "$availableSeats" },
                  regex: search,
                  options: "i",
                },
              },
            },
            {
              $expr: {
                $regexMatch: {
                  input: { $toString: "$totalSeats" },
                  regex: search,
                  options: "i",
                },
              },
            },
            {
              $expr: {
                $regexMatch: {
                  input: {
                    $dateToString: {
                      format: "%Y-%m-%d",
                      date: "$date",
                    },
                  },
                  regex: search,
                  options: "i",
                },
              },
            },
          ],
        },
      });
    }

    // ===============================
    // Sorting
    // ===============================
    pipeline.push({
      $sort: {
        [sortField]: sortOrder === "asc" ? 1 : -1,
      },
    });

    // ===============================
    // Execute Query
    // ===============================
    const tickets = await Ticket.aggregate(pipeline);

    // ===============================
    // Response
    // ===============================
    return res.status(200).json({
      success: true,
      count: tickets.length,
      tickets,
    });

  } catch (error) {
    console.error("Get Tickets Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to fetch tickets.",
      error: process.env.NODE_ENV === "development"
        ? error.message
        : undefined,
    });
  }
};

export const getTicketById = async (req, res) => {
  try {
    const ticket = await Ticket.findById(req.params.id)
      .populate("temple", "name")
      .populate("darshanType", "name");

    if (!ticket) {
      return res.status(404).json({
        success: false,
        message: "Ticket not found.",
      });
    }

    res.json({
      success: true,
      ticket,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

